<?php 
	$con = mysqli_connect("localhost","root","", "grocerydb") or die("Couldn't connect to SQL server");
?>