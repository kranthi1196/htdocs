<?php 

	error_reporting( E_ERROR | E_WARNING | E_PARSE); // To avoid error messages

	$con = mysqli_connect("localhost","root","") or die("Couldn't connect to SQL server");

	$db="grocerydb";
	$db_create = "CREATE DATABASE IF NOT EXISTS $db";
	$db_create_query = mysqli_query($con,$db_create);
	
	
?>