<?php 
$conn = mysqli_connect("localhost", "root", "test", "blog_samples");
?>