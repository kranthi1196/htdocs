<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Welcome extends Controller{
    public function index()
    {
        echo "Welcome to the CI_4 Sessions <br> Developed By Prof. Brillie Zerubbabel";
    }
    //its method calling is by http://localhost/ci4_practice/ci4_projects/public/index.php/welcome or
    //its method calling is by http://localhost/ci4_practice/ci4_projects/public/welcome or 
    //its method calling is by http://localhost/ci4_practice/ci4_projects/public/index.php/welcome/index
    public function test($name)
    {
        echo "Entered Parameter is :".$name;
    }
    //its method calling is by http://localhost/ci4_practice/ci4_projects/public/index.php/welcome/test or
    //its method calling is by http://localhost/ci4_practice/ci4_projects/public/welcome or
    //its method calling is by http://localhost/ci4_practice/ci4_projects/public/welcome/test/Kranthi
}


?>