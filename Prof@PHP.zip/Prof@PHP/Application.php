<?php

$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'practice');

if(isset($_POST['submit']))
{
    $uid=$_POST['uid'];
$tspscid=$_POST['tspscid'];
$refid=$refid;
$cand_name=$_POST['cand_name'];
$fath_hus_name=$_POST['fath_hus_name'];
$mother_name=$_POST['mother_name'];
$dob=$_POST['dob'];

$gender=$_POST["gender"];
$address=$_POST['address'];
$district=$_POST['district'];
$mandal=$_POST['mandal'];

$village=$_POST['village'];
$pincode=$_POST['pincode'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$community=$_POST['community'];

$identication_marks=$_POST['identication_marks'];
$ex_service=$_POST['ex_service'];
$employment=$_POST['employment'];
$temp_emp=$_POST['temp_emp'];
$ncc_instructor=$_POST['ncc_instructor'];
$ph_status=$_POST['ph_status'];

$eligibility_1_4_6_7_9=$_POST['eligibility_1_4_6_7_9'];
$eligibility_2=$_POST['eligibility_2']; 
$eligibility_3=$_POST['eligibility_3'];
$eligibility_5=$_POST['eligibility_5'];
$hindu=$_POST['hindu'];
$photo=$_FILES['photo']['cand_name'];
$sign=$_FILES['sign']['cand_name'];
$eligibility_10=$_POST['eligibility_10'];
$eligibility_11=$_POST['eligibility_11'];
$eligibility_12=$_POST['eligibility_12'];
$eligibility_13=$_POST['eligibility_13'];
$applied_post1=$_POST['applied_post1'];

$applied_post2=$_POST['applied_post2'];
$applied_post3=$_POST['applied_post3'];
$applied_post4=$_POST['applied_post4'];
$applied_post5=$_POST['applied_post5'];
$applied_post6=$_POST['applied_post6'];
$applied_post7=$_POST['applied_post7'];
$applied_post8=$_POST['applied_post8'];
$applied_post9=$_POST['applied_post9'];
$applied_post10=$_POST['applied_post10'];
$applied_post11=$_POST['applied_post11'];
$applied_post12=$_POST['applied_post12'];

$applied_post13=$_POST['applied_post13'];
$qualification=$_POST['qualification'];
$university=$_POST['university'];
$doa=$_POST['doa'];
$deg_htnum=$_POST['deg_htnum'];
$typeofstudy=$_POST['typeofstudy'];
$zone=$_POST['zone'];
$degree_loc=$_POST['degree_loc'];
$degree_mandal_loc=$_POST['degree_mandal_loc'];
$degree_village_loc=$_POST['degree_village_loc'];
$inter_loc=$_POST['inter_loc'];

$inter_mandal_loc=$_POST['inter_mandal_loc'];
$inter_village_loc=$_POST['inter_village_loc'];
$ssc_loc=$_POST['ssc_loc'];
$ssc_mandal_loc=$_POST['ssc_mandal_loc'];
$ssc_village_loc=$_POST['ssc_village_loc'];
$cls9_loc=$_POST['cls9_loc'];
$cls9_mandal_loc=$_POST['cls9_mandal_loc'];
$cls9_village_loc=$_POST['cls9_village_loc'];
$cls8_loc=$_POST['cls8_loc'];

$cls8_mandal_loc=$_POST['cls8_mandal_loc']; 

$cls8_village_loc=$_POST['cls8_village_loc'];
$cls7_loc=$_POST['cls7_loc'];
$cls7_mandal_loc=$_POST['cls7_mandal_loc'];
$cls7_village_loc=$_POST['cls7_village_loc'];
$cls6_loc=$_POST['cls6_loc'];
$cls6_mandal_loc=$_POST['cls6_mandal_loc'];
$cls6_village_loc=$_POST['cls6_village_loc'];
$journal_num=$_POST['journal_num'];
$payment_date=$_POST['payment_date'];
$fee=$_POST['fee'];
$pref_1=$_POST['pref_1'];

$pref_2=$_POST['pref_2'];
$pref_3=$_POST['pref_3'];
$pref_4=$_POST['pref_4'];
$pref_5=$_POST['pref_5'];
$pref_6=$_POST['pref_6'];
$pref_7=$_POST['pref_7'];
$pref_8=$_POST['pref_8'];
$pref_9=$_POST['pref_9'];
$pref_10=$_POST['pref_10'];
    
$query= " INSERT INTO mk(`uid`,`tspscid`,`cand_name`,`fath_hus_name`,`mother_name`,`dob`,`gender`,`address`,`district`,`mandal`,`village`,`pincode`,`mobile`,`email`,`community`,`identication_marks`,`ex_service`,`employment`,`temp_emp`,`ncc_instructor`,`ph_status`,`eligibility_1_4_6_7_9`,`eligibility_2`,`eligibility_3`,`eligibility_5`,`hindu`,`photo`,`sign`,`eligibility_10`,`eligibility_11`,`eligibility_12`,`eligibility_13`,`applied_post1`,`applied_post2`,`applied_post3`,`applied_post4`,`applied_post5`,`applied_post6`,`applied_post7`,`applied_post8`,`applied_post9`,`applied_post10`,`applied_post11`,`applied_post12`,`applied_post13`,`qualification`,`university`,`doa`,`deg_htnum`,`typeofstudy`,`zone`,`degree_loc`,`inter_loc`,`ssc_loc`,`cls9_loc`,`cls8_loc`,`cls7_loc`,`cls6_loc`,`journal_num`,`payment_date`,`fee`,`pref_1`,`pref_2`,`pref_3`,`pref_4`,`pref_5`,`pref_6`,`pref_7`,`pref_8`,`pref_9`,`pref_10`) VALUES('$id','$uid','$tspscid','$cand_name','$fath_hus_name','$mother_name','$dob','$gender','$address','$district','$mandal','$village','$pincode','$mobile','$email','$community','$identication_marks','$ex_service','$employment','$temp_emp','$ncc_instructor','$ph_status','$eligibility_1_4_6_7_9','$eligibility_2','$eligibility_3','$eligibility_5','$hindu','$photo','$sign','$eligibility_10','$eligibility_11','$eligibility_12','$eligibility_13','$applied_post1','$applied_post2','$applied_post3','$applied_post4','$applied_post5','$applied_post6','$applied_post7','$applied_post8','$applied_post9','$applied_post10','$applied_post11','$applied_post12','$applied_post13','$qualification','$university','$doa','$deg_htnum','$typeofstudy','$zone','$degree_loc','$inter_loc','$ssc_loc','$cls9_loc','$cls8_loc','$cls7_loc','$cls6_loc','$journal_num','$payment_date','$fee','$pref_1','$pref_2','$pref_3','$pref_4','$pref_5','$pref_6','$pref_7','$pref_8','$pref_9','$pref_10')";
//    $query = "INSERT INTO student(`fname`,`lname`,`contact`) VALUES ('$fname','$lname','$contact')";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        echo '<script> alert("Your Data is being Saved to the DataBase"); </script>';
        
    }
    else
    {
        echo '<script> alert("Data Not Saved into the Data Base"); </script>';
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group 2 Application</title>
    <link rel="stylesheet" type="text/css" href="./CSS/prev2.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css1">


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
<script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>

<script>
    document.addEventListener('contextmenu', event => event.preventDefault());
</script>


</head>
<body>

    <?php
if(isset($_SESSION['status']) && $_SESSION!=''){
    ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>Hey!</strong> Your Data is Being Saved to the Data Base<!--<?php echo $_SESSION['status']; ?>-->
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php
unset($_SESSION['status']);
}
?>

    <center><img class="tspsc_logo" id="tspsc_logo"    src="./Images/TSPSC_Logo.png" alt="TSPSC Logo"><br><h1>TELANGANA STATE PUBLIC SERVICE COMMISSION :: HYDERABAD</h1>
    <h2>GROUP-II SERVICES</h2>
    <h2>(GENERAL RECRUITMENT)</h2>
    <h2>SUPPLEMENTARY NOTIFICATION NO. 17/2016 TO NOTIFICATION NO. 20/2015, Dated.01/09/2016</h2></center>
    <form action="Prev_test.php" method="post">
        <fieldset>
        <legend><b> Candidate Details.</b></legend>
        <table>
    <tr><br><td><b>Unique Identification Number (UID)/Aadhar Number * : </td><td><input type="text" name="uid" required placeholder="7913 9305 5275"></b></td></tr>
    <tr><td><b>TSPSC ID * :</td> <td><input type="text" name="tspscid" required placeholder="TS029"></b></td></tr>
    <!--<tr><td><b>Reference ID :</td><td><input type="text" name="refid" placeholder="Dont Fill This"></b></td></tr>-->
    <tr><td><b>Candidate Name * :</td><td><input type="text" name="cand_name" required placeholder="KRANTHI KUMAR MARIKANTI"></b></td></tr>
    <tr><td><b>Father's/Husband's Name :</td><td><input type="text" name="fath_hus_name" id="" placeholder="SANJEEVA MARIKANTI"></b></td></tr>
    <tr><td><b>Mother's Name :</td><td><input type="text" name="mother_name" placeholder="RAMANA MARIKANTI"></b></td></tr> 
    <tr><td><b>Date of Birth * :</td><td><input type="calender" name="dob" required placeholder="15/03/1993"></b></td></tr> 
    <tr><td><b>Gender :</td><td><input type="radio" name="gender" value="Male">Male <input type="radio" name="gender" value="Female">Female</b></td></tr> 
    <tr><td><b>Address for Communication :</td><td><input type="textarea" name="address" id="" placeholder="4-140, THALLASINGARAM, NUTHANKAL, SURYAPET"></b></td></tr> 
    <tr><td><b>District :</td><td><input type="text" name="district" id="" placeholder="SURYAPET"></b></td></tr> 
    <tr><td><b>Mandal :</td><td><input type="text" name="mandal" placeholder="NUTHANKAL"></b></td></tr> 
    <tr><td><b>Village :</td><td><input type="text" name="village" id="" placeholder="THALLSINGARAM"></b></td></tr> 
    <tr><td><b>Pincode :</td><td><input type="text" name="pincode" placeholder="508221"></b></td></tr> 
    <tr><td><b>Mobile Number * :</td><td><input type="text" name="mobile" id="" required placeholder="9640735588"></b></td></tr> 
    <tr><td><b>E-mail * :</td><td><input type="text" name="email" id="" required placeholder="kranthi.marikanti@gmail.com"></b></td></tr> 
    <tr><td><b>Community :</td><td><input type="radio"  name="community" value="SC">SC 
    <input type="radio" name="community" id="" value="ST">ST
    <input type="radio" name="community" id="" value="OBC">OBC</b></td></tr> 
    <tr><td><b>Identification Marks as per SSC Certificate :</td><td><input type="text" name="identication_marks" id="" placeholder="A MOLE ON THE LEFT LEG"></b></td></tr> 
    <tr><td><b>Are you and Ex Service man :</td><td><input type="radio" name="ex_service" id="" value="Yes" value="Yes">Yes <input type="radio" name="ex_service" id="" value="No" value="No">No</b></td></tr> 
    <tr><td><b>Govt Employment Status :</td><td><input type="radio" name="employment" value="Yes" value="Yes">Yes <input type="radio" name="employment" id="" value="No" value="No">No</b></td></tr> 
    <tr><td><b>Are you retrenched temporary employee in State Census Department :</td><td><input type="radio" name="temp_emp" id="" value="Yes" value="Yes">Yes <input type="radio" name="temp_emp" id="" value="No" value="No">No</b></td></tr> 
    <tr><td><b>Worked as Instructor in NCC :</td><td><input type="radio" name="ncc_instructor" id=""  value="Yes">Yes <input type="radio" name="ncc_instructor" id="" value="No">No</b></td></tr> 
    <tr><td><b>Are you a Physically Handicapped :</td><td><input type="radio" name="ph_status" id="" value="Yes">Yes <input type="radio" name="ph_status" id="" value="No">No<b></td></tr> 

    <tr><td><b>Do You Possess Qualification and Eligibility for Post Codes 01, 04, 06, 07, 09 as per Notification? :</td><td><input type="radio" name="eligibility_1_4_6_7_9" id="" value="Yes"> Yes <input type="radio" name="eligibility_1_4_6_7_9" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Possess Qualification and Eligibility for Post Code 02 as per Notification :</td><td><input type="radio" name="eligibility_2" id="" value="Yes">Yes <input type="radio" name="eligibility_2" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Possess Qualification and Eligibility for Post Code 03 as per Notification :</td><td><input type="radio" name="eligibility_3" id="" value="Yes">Yes <input type="radio" name="eligibility_3" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Possess Qualification, Eligibility and Physical Requirements For Pc. No. 05 as per Notification :</td><td><input type="radio" name="eligibility_5" id="" value="Yes">Yes <input type="radio" name="eligibility_5" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Profess Hindu Religion :</td><td><input type="radio" name="hindu" id="" value="Yes">Yes <input type="radio" name="hindu" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Possess Qualification and Eligibility for Post Code 10 as per Notification :</td><td><input type="radio" name="eligibility_10" id="" value="Yes">Yes <input type="radio" name="eligibility_10" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Possess Qualification and Eligibility for Post Code 11 as per Notification :</td><td><input type="radio" name="eligibility_11" id="" value="Yes">Yes <input type="radio" name="eligibility_11" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Possess Qualification and Eligibility for Post Code 12 as per Notification :</td><td><input type="radio" name="eligibility_12" id="" value="Yes">Yes <input type="radio" name="eligibility_12" id="" value="No">No</b></td></tr> 
    <tr><td><b>Do You Possess Qualification and Eligibility for Post Code 13 as per Notification :</td><td><input type="radio" name="eligibility_13" id="" value="Yes">Yes <input type="radio" name="eligibility_13" id="" value="No">No</b></td></tr> 
    <tr><td><b>Apply for the Post :</b></td><td><input type="checkbox" name="applied_post1" id="" value="1. Municipal Commissioner Gr.III in (Municipal Administration Sub Service) ">1. Municipal Commissioner Gr.III in (Municipal Administration Sub Service) <br>
        <input type="checkbox" name="applied_post2" id="" value="2. Assistant Commercial Tax Officer (Commercial Tax Sub-Service)">2. Assistant Commercial Tax Officer (Commercial Tax Sub-Service) <br>        
        <input type="checkbox" name="applied_post3" id="" value="3. Sub-Registrar Gr.II (Registration Sub - Service)">3. Sub-Registrar Gr.II (Registration Sub - Service) <br>
        <input type="checkbox" name="applied_post4" id="" value="4. Extension Officer (Panchayat Raj and Rural Development Sub Service)">4. Extension Officer (Panchayat Raj and Rural Development Sub Service) <br>
        <input type="checkbox" name="applied_post5" id="" value="5. Prohibition and Excise Sub Inspector (Excise Sub-Service)">5. Prohibition and Excise Sub Inspector (Excise Sub-Service) <br>
        <input type="checkbox" name="applied_post6" id="" value="6. Deputy Tahsildar in Land Administration">6. Deputy Tahsildar in Land Administration <br>
        <input type="checkbox" name="applied_post7" id="" value="7. Assistant Registrar in Registrar of Co - operative Societies">7. Assistant Registrar in Registrar of Co - operative Societies <br>
        <input type="checkbox" name="applied_post8" id="" value="8. Executive Officer Grade-I in Endowments Department">8. Executive Officer Grade-I in Endowments Department <br>
        <input type="checkbox" name="applied_post9" id="" value="9. Assistant Labour officer in Commissioner of Labour Department">9. Assistant Labour officer in Commissioner of Labour Department <br>
        <input type="checkbox" name="applied_post10" id="" value="10. Assistant Development Officer in Handlooms & Textiles">10. Assistant Development Officer in Handlooms & Textiles <br>
        <input type="checkbox" name="applied_post11" id="" value="11. Assistant Section Officer GAD(Single Unit) Secretariat">11. Assistant Section Officer GAD(Single Unit) Secretariat <br>
        <input type="checkbox" name="applied_post12" id="" value="12. Assistant Section Officer in Finance Department Secretariat ">12. Assistant Section Officer in Finance Department Secretariat <br>
        <input type="checkbox" name="applied_post13" id="" value="13. Assistant Section Officer in Law Department Secretariat">13. Assistant Section Officer in Law Department Secretariat</td></tr>
    </table>
</fieldset>
<br>
<fieldset>
    <legend><b> Academic Details.</b></legend>
    <table style="width: inherit;">

    <tr><td><b>Qualification * :</b></td><td><input type="radio" name="qualification" required id="" value="A Master's Degree from any recognized University in India established or incorporated by or under Central Act,
        Provincial Act, a State Act or an Institution recognized by the U.G.C.">Masters Degree<input type="radio" name="qualification" id="" value="A Bachelor's Degree from any recognized University in India established or incorporated by or under Central Act,
        Provincial Act, a State Act or an Institution recognized by the U.G.C.">Bachelors Degree</td></tr>
    <tr><td><b>University :</b></td><td><input type="text" name="university" id="" placeholder="JNTU-H"></td></tr>
    <tr><td><b>Date of Acquiring Qualification :</b></td><td><input type="text"  name="doa" id="" placeholder="25/05/2016"></td></tr>
    <tr><td><b>Hallticket No. of Degree Examination * :</b></td><td><input type="text" required name="deg_htnum" id="" placeholder="12631A0423"></td></tr>
    <tr><td><b>Type of Study</b></td><td><input type="radio" name="typeofstudy" id="" value="Regular">Regular <input type="radio" name="typeofstudy" id="" value="Distance"> Distance</td></tr>
    <tr><td><b>Zone as Indicated by the Candidate in OTR * :</b></td><td><input type="radio" required name="zone" id="" value="Zone - I">Zone I<input type="radio" name="zone" id="" value="Zone - II">Zone II <input type="radio" name="zone" id="" value="Zone - III">Zone III<input type="radio" name="zone" id="" value="Zone - IV">Zone IV <input type="radio" name="zone" id="" value="Zone - V">Zone V<input type="radio" name="zone" id="" value="Zone - VI">Zone VI</td></tr>
</table>
</fieldset>   
<br>
<fieldset>
    <legend><b> Education Details.</b></legend>
    <table>
    
    <tr><td><b>Degree :</b></td><td>
        <select name="degree_loc" id="" >
        <option name="district" value="Select">Select Your District</option>
        <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select>
         &nbsp; &nbsp;<input type="text" name="degree_mandal_loc" id="" placeholder="Mandal / Muncipality">&nbsp; &nbsp;<input type="text" name="degree_village_loc" id="" placeholder="Village/ Area / Ward "></td></tr>

         <tr><td><b>Intermediate :</b></td><td>
            <select name="inter_loc" id="" >
                <option name="district" value="Select">Select Your District</option>
                <option name="district" value="ADILABAD">ADILABAD</option>
                <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
                <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
                <option name="district" value="HYDERABAD">HYDERABAD</option>
                <option name="district" value="JAGTIAL">JAGTIAL</option>
                <option name="district" value="JANGOAN">JANGOAN</option>
                <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
                <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
                <option name="district" value="KAMAREDDY">KAMAREDDY</option>
                <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
                <option name="district" value="KHAMMAM">KHAMMAM</option>
                <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
                <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
                <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
                <option name="district" value="MANCHERIAL">MANCHERIAL</option>
                <option name="district" value="MEDAK">MEDAK</option>
                <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
                <option name="district" value="MULUGU">MULUGU</option>
                <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
                <option name="district" value="NALGONDA">NALGONDA</option>
                <option name="district" value="NARAYANPET">NARAYANPET</option>
                <option name="district" value="NIRMAL">NIRMAL</option>
                <option name="district" value="NIZAMABAD">NIZAMABAD</option>
                <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
                <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
                <option name="district" value="RANGAREDDY">RANGAREDDY</option>
                <option name="district" value="SANGAREDDY">SANGAREDDY</option>
                <option name="district" value="SIDDIPET">SIDDIPET</option>
                <option name="district" value="SURYAPET">SURYAPET</option>
                <option name="district" value="VIKARABAD">VIKARABAD</option>
                <option name="district" value="WANAPARTHY">WANAPARTHY</option>
                <option name="district" value="WARANGAL">WARANGAL</option>
                <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
            </select>
             &nbsp; &nbsp;<input type="text" name="inter_mandal_loc" id="" placeholder="Mandal / Muncipality">&nbsp; &nbsp;<input type="text" name="inter_village_loc" id="" placeholder="Village/ Area / Ward "></td></tr>

             <tr><td><b>SSC :</b></td><td>
                <select name="ssc_loc" id="" >
                    <option name="district" value="Select">Select Your District</option>
        <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
                </select>
                 &nbsp; &nbsp;<input type="text" name="ssc_mandal_loc" id="" placeholder="Mandal / Muncipality">&nbsp; &nbsp;<input type="text" name="ssc_village_loc" id="" placeholder="Village/ Area / Ward "></td></tr>
                 
                 <tr><td><b>9th :</b></td><td>
                    <select name="cls9_loc" id="" >
                        <option name="district" value="Select">Select Your District</option>
                        <option name="district" value="Select">Select Your District</option>
        <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
                    </select>
                     &nbsp; &nbsp;<input type="text" name="cls9_mandal_loc" id="" placeholder="Mandal / Muncipality">&nbsp; &nbsp;<input type="text" name="cls9_village_loc" id="" placeholder="Village/ Area / Ward "></td></tr>


                     <tr><td><b>8th :</b></td><td>
                        <select name="cls8_loc" id="" >
                            <option name="district" value="Select">Select Your District</option>
        <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
                        </select>
                         &nbsp; &nbsp;<input type="text" name="cls8_mandal_loc" id="" placeholder="Mandal / Muncipality">&nbsp; &nbsp;<input type="text" name="cls8_village_loc" id="" placeholder="Village/ Area / Ward "></td></tr>

                         <tr><td><b>7th :</b></td><td>
                            <select name="cls7_loc" id="" >
                                <option name="district" value="Select">Select Your District</option>
        <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
                            </select>
                             &nbsp; &nbsp;<input type="text" name="cls7_mandal_loc" id="" placeholder="Mandal / Muncipality">&nbsp; &nbsp;<input type="text" name="cls7_village_loc" id="" placeholder="Village/ Area / Ward "></td></tr>

                             <tr><td><b>6th :</b></td><td>
                                <select name="cls6_loc" id="" >
                                    <option name="district" value="Select">Select Your District</option>
        <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
                                </select>
                                 &nbsp; &nbsp;<input type="text" name="cls6_mandal_loc" id="" placeholder="Mandal / Muncipality">&nbsp; &nbsp;<input type="text" name="cls6_village_loc" id="" placeholder="Village/ Area / Ward "></td></tr>

                </table>
</fieldset>
<br>

<fieldset>
    <legend><b> Personal Details.</b></legend>
    <table>

    <tr><td><b>Candidate Photo * :</b></td><td><input type="hidden" required name="MAX_FILE_SIZE" value="500"><br> <input type="file" name="photo" id="" value="upload"><br></td></tr>

    <tr><td><b>Candidate Signature * :</b></td><td><input type="hidden" required name="MAX_FILE_SIZE" value="500"><br> <input type="file" name="sign" id="" value="upload"></td></tr>
    
</table>
</fieldset>   

<br>
<fieldset>
    <legend><b> Payment Details.</b></legend>
    <table>
        <tr><td><b>Journal Number * :</b></td><td><input type="text" required name="journal_num" id="" placeholder="TSPSC12345678932"></td></tr>
        <tr><td><b>Payment Date * :</b></td><td><input type="text" required name="payment_date" id="" placeholder="01/09/2016"></td></tr>
        <tr><td><b>Amount * :</b></td><td><input type="text" required name="fee" id="" placeholder="200.0"></td></tr>

    <tr><td><b></b></td><td></td></tr>
</table>
</fieldset>
<br>
<fieldset>
    <legend><b> Exam Centers.</b></legend>
    <table>
        <tr><td><b>Preference 1 :</b></td><td><select name="pref_1" id=""  >
            <option name="district" value="Select">Select Exam Center 1</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 2 :</b></td><td><select name="pref_2" id="" >
            <option name="district" value="Select">Select Exam Center 2</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 3 :</b></td><td><select name="pref_3" id="" >
            <option name="district" value="Select">Select Exam Center 3</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 4 :</b></td><td><select name="pref_4" id="" >
            <option name="district" value="Select">Select Exam Center 4</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 5 :</b></td><td><select name="pref_5" id="" >
            <option name="district" value="Select">Select Exam Center 5</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 6 :</b></td><td><select name="pref_6" id="" >
            <option name="district" value="Select">Select Exam Center 6</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 7 :</b></td><td><select name="pref_7" id="" >
            <option name="district" value="Select">Select Exam Center 7</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 8 :</b></td><td><select name="pref_8" id="" >
            <option name="district" value="Select">Select Exam Center 8</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 9 :</b></td><td><select name="pref_9" id="" >
            <option name="district" value="Select">Select Exam Center 9</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
        <tr><td><b>Preference 10 :</b></td><td><select name="pref_10" id="" >
            <option name="district" value="Select">Select Exam Center 10</option>
            <option name="district" value="ADILABAD">ADILABAD</option>
        <option name="district" value="BHADRADRI KOTHAGUDEM">BHADRADRI KOTHAGUDEM</option>
        <option name="district" value="HANUMAKONDA">HANUMAKONDA</option>
        <option name="district" value="HYDERABAD">HYDERABAD</option>
        <option name="district" value="JAGTIAL">JAGTIAL</option>
        <option name="district" value="JANGOAN">JANGOAN</option>
        <option name="district" value="JAYASHANKAR BHOOPALPALLY">JAYASHANKAR BHOOPALPALLY</option>
        <option name="district" value="JOGULAMBA GADWAL">JOGULAMBA GADWAL</option>
        <option name="district" value="KAMAREDDY">KAMAREDDY</option>
        <option name="district" value="KARIMNAGAR">KARIMNAGAR</option>
        <option name="district" value="KHAMMAM">KHAMMAM</option>
        <option name="district" value="KOMARAM BHEEM ASIFABAD">KOMARAM BHEEM ASIFABAD</option>
        <option name="district" value="MAHABUBABAD">MAHABUBABAD</option>
        <option name="district" value="MAHABUBNAGAR">MAHABUBNAGAR</option>
        <option name="district" value="MANCHERIAL">MANCHERIAL</option>
        <option name="district" value="MEDAK">MEDAK</option>
        <option name="district" value="MEDCHAL-MALKAJGIRI">MEDCHAL-MALKAJGIRI</option>
        <option name="district" value="MULUGU">MULUGU</option>
        <option name="district" value="NAGARKURNOOL">NAGARKURNOOL</option>
        <option name="district" value="NALGONDA">NALGONDA</option>
        <option name="district" value="NARAYANPET">NARAYANPET</option>
        <option name="district" value="NIRMAL">NIRMAL</option>
        <option name="district" value="NIZAMABAD">NIZAMABAD</option>
        <option name="district" value="PEDDAPALLI">PEDDAPALLI</option>
        <option name="district" value="RAJANNA SIRCILLA">RAJANNA SIRCILLA</option>
        <option name="district" value="RANGAREDDY">RANGAREDDY</option>
        <option name="district" value="SANGAREDDY">SANGAREDDY</option>
        <option name="district" value="SIDDIPET">SIDDIPET</option>
        <option name="district" value="SURYAPET">SURYAPET</option>
        <option name="district" value="VIKARABAD">VIKARABAD</option>
        <option name="district" value="WANAPARTHY">WANAPARTHY</option>
        <option name="district" value="WARANGAL">WARANGAL</option>
        <option name="district" value="YADADRI BHUVANAGIRI">YADADRI BHUVANAGIRI</option>
        </select></td></tr>
</table> <br><br><br>



<center><input type="submit" name="submit" id="" value="submit"></center>

    <tr><td><b><br></b></td><td><br></td></tr>
    </form>
</body>
</html>
