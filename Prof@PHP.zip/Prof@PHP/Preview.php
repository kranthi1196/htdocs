<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./CSS/prev2.css">

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css1" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css1" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js1" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <title>::Confirmation Page::</title>
</head>
<body>

<?php

error_reporting( E_ERROR | E_WARNING | E_PARSE);


/* Variables to store the User Data */


$refid=000000;

$uid=$_POST['uid'];
$tspscid=$_POST['tspscid'];
$refid=$refid;
$cand_name=$_POST['cand_name'];
$fath_hus_name=$_POST['fath_hus_name'];
$mother_name=$_POST['mother_name'];
$dob=$_POST['dob'];

$gender=$_POST["gender"];
$address=$_POST['address'];
$district=$_POST['district'];
$mandal=$_POST['mandal'];

$village=$_POST['village'];
$pincode=$_POST['pincode'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$community=$_POST['community'];

$identication_marks=$_POST['identication_marks'];
$ex_service=$_POST['ex_service'];
$employment=$_POST['employment'];
$temp_emp=$_POST['temp_emp'];
$ncc_instructor=$_POST['ncc_instructor'];
$ph_status=$_POST['ph_status'];

$eligibility_1_4_6_7_9=$_POST['eligibility_1_4_6_7_9'];
$eligibility_2=$_POST['eligibility_2']; 
$eligibility_3=$_POST['eligibility_3'];
$eligibility_5=$_POST['eligibility_5'];
$hindu=$_POST['hindu'];
$photo=$_POST['photo'];
$sign=$_POST['sign'];
$eligibility_10=$_POST['eligibility_10'];
$eligibility_11=$_POST['eligibility_11'];
$eligibility_12=$_POST['eligibility_12'];
$eligibility_13=$_POST['eligibility_13'];
$applied_post1=$_POST['applied_post1'];

$applied_post2=$_POST['applied_post2'];
$applied_post3=$_POST['applied_post3'];
$applied_post4=$_POST['applied_post4'];
$applied_post5=$_POST['applied_post5'];
$applied_post6=$_POST['applied_post6'];
$applied_post7=$_POST['applied_post7'];
$applied_post8=$_POST['applied_post8'];
$applied_post9=$_POST['applied_post9'];
$applied_post10=$_POST['applied_post10'];
$applied_post11=$_POST['applied_post11'];
$applied_post12=$_POST['applied_post12'];

$applied_post13=$_POST['applied_post13'];
$qualification=$_POST['qualification'];
$university=$_POST['university'];
$doa=$_POST['doa'];
$deg_htnum=$_POST['deg_htnum'];
$typeofstudy=$_POST['typeofstudy'];
$zone=$_POST['zone'];
$degree_loc=$_POST['degree_loc'];
$degree_mandal_loc=$_POST['degree_mandal_loc'];
$degree_village_loc=$_POST['degree_village_loc'];
$inter_loc=$_POST['inter_loc'];

$inter_mandal_loc=$_POST['inter_mandal_loc'];
$inter_village_loc=$_POST['inter_village_loc'];
$ssc_loc=$_POST['ssc_loc'];
$ssc_mandal_loc=$_POST['ssc_mandal_loc'];
$ssc_village_loc=$_POST['ssc_village_loc'];
$cls9_loc=$_POST['cls9_loc'];
$cls9_mandal_loc=$_POST['cls9_mandal_loc'];
$cls9_village_loc=$_POST['cls9_village_loc'];
$cls8_loc=$_POST['cls8_loc'];

$cls8_mandal_loc=$_POST['cls8_mandal_loc']; 

$cls8_village_loc=$_POST['cls8_village_loc'];
$cls7_loc=$_POST['cls7_loc'];
$cls7_mandal_loc=$_POST['cls7_mandal_loc'];
$cls7_village_loc=$_POST['cls7_village_loc'];
$cls6_loc=$_POST['cls6_loc'];
$cls6_mandal_loc=$_POST['cls6_mandal_loc'];
$cls6_village_loc=$_POST['cls6_village_loc'];
$journal_num=$_POST['journal_num'];
$payment_date=$_POST['payment_date'];
$fee=$_POST['fee'];
$pref_1=$_POST['pref_1'];

$pref_2=$_POST['pref_2'];
$pref_3=$_POST['pref_3'];
$pref_4=$_POST['pref_4'];
$pref_5=$_POST['pref_5'];
$pref_6=$_POST['pref_6'];
$pref_7=$_POST['pref_7'];
$pref_8=$_POST['pref_8'];
$pref_9=$_POST['pref_9'];
$pref_10=$_POST['pref_10'];
//$submit=$_POST['submit'];

$date = date('m/d/Y h:i:s a', time());



if(isset($_POST['photo']))
{ 
$filepath = "images/" . $_FILES["file"]["name"];

if(move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) 
{
$photo = "<img src=".$filepath." height=200 width=300 />";
} 
else 
{
echo "Error !!";
}
} 


if(isset($_POST['sign']))
{ 
$filepath = "images/" . $_FILES["file"]["name"];

if(move_uploaded_file($_FILES["file"]["tmp_name"], $filepath)) 
{
$sign = "<img src=".$filepath." height=200 width=300 />";
} 
else 
{
echo "Error !!";
}
} 


/* Confirmation form */ 




print "<center><img class=\"tspsc_logo\" id=\"tspsc_logo\"    src=\"./Images/TSPSC_Logo.png\" alt=\"TSPSC Logo\"></center>";
print "<center><h4>TELANGANA STATE PUBLIC SERVICE COMMISSION :: HYDERABAD</h4>
<h5>GROUP-II SERVICES</h5>
<h5>(GENERAL RECRUITMENT)</h5>
<h5>SUPPLEMENTARY NOTIFICATION NO. 17/2016 TO NOTIFICATION NO. 20/2015, Dated.01/09/2016</h5></center>";

//print "";
/*<div class=\"row justify-content-center\">
<div class=\"col-auto\">
  <table class=\"table table-responsive\">
  
  table table-bordered
  
  */

print " <center><div class=\"col-auto\"><table border=\"1px\" cellpadding=\"0\" class=\" table-striped\">
<tbody style=\"\">
<tr>
    <td class=\"slnum\">1. </td> <td colspan=\"3\" style=\"padding-left:5px\"><b> Unique Identification Number (UID)/Aadhaar Number :</b> $uid</td> <td rowspan=\"6\" style=\"width: 150px;\"><img src=\"\" alt=\"Candidate Photo\">$photo</td></tr>
    <tr><td class=\"slnum\">2. </td><td class=\"tdwidth\"style=\"padding-left:5px\"><b> TSPSC ID :</b> $tspscid</td><td class=\"slnum\">3.</td><td class=\"tdwidth\" style=\"padding-left:5px\"><b>Reference Id : </b>$refid</td></tr>
                    <tr><td class=\"slnum\">4. </td><td style=\"padding-left:5px\"><b> Candidate Name : </b>$cand_name</td><td class=\"slnum\">5.</td><td class=\"tdwidth\" style=\"padding-left:5px\"><b> Father's/Husband`s Name :</b> $fath_hus_name</td></tr>
                    <tr><td class=\"slnum\">6. </td><td colspan=\"3\" style=\"padding-left:5px\"><b> Mother's Name :</b> $mother_name</td></tr>
                    <tr><td class=\"slnum\">7. </td><td style=\"padding-left:5px\"><b> <b>Date of Birth :</b> $dob</td><td class=\"slnum\">8.</td><td style=\"padding-left:5px\"><b> Gender : </b>$gender</td></tr>
                    <tr><td class=\"slnum\">9. </td><td colspan=\"3\" style=\"padding-left:5px\"><b>Address for communication :</b> $address</td> <td></td></tr>
                    <tr><td class=\"slnum\">10.</td><td colspan=\"3\"style=\"padding-left:5px\"><b>District/Mandal/Village :</b> $district/$mandal/$village</td><td><img src=\"\" alt=\"Candidate Signature\">$sign</td></tr>
                    <tr><td class=\"slnum\">11.</td><td colspan=\"3\"style=\"padding-left:5px\"><b>Pincode :</b> $pincode <b>Mobile :</b> $mobile <b>E-mail :</b> $email</td><td rowspan=\"6\"></td></tr>
                    <tr><td class=\"slnum\">12.</td><td colspan=\"3\" style=\"padding-left:5px\"><b>Community :</b> $community </td></tr>
                    <tr><td class=\"slnum\">13.</td><td colspan=\"3\" style=\"padding-left:5px\"><b>Identification Marks as per SSC certificate :</b> $identication_marks</td></tr>
                    <tr><td class=\"slnum\">14.</td><td colspan=\"3\" style=\"padding-left:5px\"><b>Are you an Ex-Service man : </b>$ex_service, <b>Govt Employment Status :</b> $employment</td></tr>
                    <tr><td class=\"slnum\">15.</td><td colspan=\"3\" style=\"padding-left:5px\"><b>Are you retrenched temporary employee in State Census department :</b> $temp_emp</td></tr>
                    <tr><td class=\"slnum\">16. </td><td style=\"padding-left:5px\"><b> Do you Worked as instructor in NCC :</b> $ncc_instructor</td><td class=\"slnum\">17.</td><td style=\"padding-left:5px\"><b>Are you a PH-Person : </b>$ph_status</td></tr>
                    <tr><td class=\"slnum\">18. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification and Eligibility for Post Codes 01, 04, 06, 07, 09 as per Notification? : </b>$eligibility_1_4_6_7_9</td></tr>
                    <tr><td class=\"slnum\">19. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification and Eligibility for Post Code 02 as per Notification : </b>$eligibility_2</td></tr>
                    <tr><td class=\"slnum\">20. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification and Eligibility for Post Code 03 as per Notification : </b>$eligibility_3</td></tr>
                    <tr><td class=\"slnum\">21. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification, Eligibility and Physical Requirements For Pc. No. 05 as per Notification : </b>$eligibility_5</td></tr>
                    <tr><td class=\"slnum\">22. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Profess Hindu Religion : </b>$hindu</td></tr>
                    <tr><td class=\"slnum\">23. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification and Eligibility for Post Code 10 as per Notification : </b>$eligibility_10</td></tr>
                    <tr><td class=\"slnum\">24. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification and Eligibility for Post Code 11 as per Notification : </b>$eligibility_11</td></tr>
                    <tr><td class=\"slnum\">25. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification and Eligibility for Post Code 12 as per Notification : </b>$eligibility_12</td></tr>
                    <tr><td class=\"slnum\">26. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Do You Possess Qualification and Eligibility for Post Code 13 as per Notification : </b>$eligibility_13</td></tr>
                    <tr><td class=\"slnum\">27. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Applied Posts :
                    <br></b>$applied_post1<br>$applied_post2<br>$applied_post3<br>$applied_post4<br>$applied_post5<br>$applied_post6<br>$applied_post7<br>$applied_post8<br>$applied_post9<br>$applied_post10<br>$applied_post11<br>$applied_post12<br>$applied_post13<br></td></tr>
                    <tr><td class=\"slnum\">27a. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Qualification : </b>$qualification  </td></tr>
                    <tr><td class=\"slnum\">27b. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>University : </b>$university</td></tr>
                    <tr><td class=\"slnum\">28. </td><td style=\"width: 440px; padding-left:5px\" ><b>Date of Acquiring Qualification : </b>$doa <br> <b>Hallticket No. of Degree Examination : </b>$deg_htnum</td><td class=\"slnum\">29.</td><td colspan=\"2\" style=\"padding-left:5px\"><b>Type of Study : </b>$typeofstudy</td></tr>
                    <tr><td class=\"slnum\">30. </td><td colspan=\"4\" style=\"padding-left:5px\"><b>Zone as Indicated by the Candidate in OTR : </b>$zone</td></tr>
                    
                    </table><br>


                    <table border=\"1px\" style=\"width:1000px;\" class=\"edu_details\">
                   <tr><td colspan=\"9\"><center><b>31. Education Details  </b></center></td></tr>
                   <tr><td style=\"max-width:123px; text-align: center;\">6th/Residence 1st yr</td><td style=\"max-width:123px ;text-align: center;\">7th/Residence 2nd yr</td><td style=\"max-width:123px ;text-align: center;\">8th/Residence 3rd yr</td><td style=\"max-width:123px ;text-align: center;\">9th/Residence 4th yr</td><td style=\"max-width:123px ;text-align: center;\">SSC</td><td style=\"max-width:123px ;text-align: center;\">Intermediate</td><td style=\"max-width:123px ;text-align: center;\">Degree</td></tr>
                   <tr><td style=\"max-width:123px ;text-align: center;\">$cls6_loc</td><td style=\"max-width:123px ;text-align: center;\">$cls7_loc</td><td style=\"max-width:123px ;text-align: center;\">$cls8_loc</td><td style=\"max-width:123px ;text-align: center;\">$cls9_loc</td><td style=\"max-width:123px ;text-align: center;\">$ssc_loc</td><td style=\"max-width:123px ;text-align: center;\">$inter_loc</td><td style=\"max-width:123px ;text-align: center;\">$degree_loc</td></tr>
               </table> 
               <br>
               
               <table border=\"1px\">
             <tr><td colspan=\"9\"><center><b>32. Payment Details </b> </center></td></tr>
             <tr><td style=\"width:300px; text-align: center;\">Journal Number</td><td style=\"width:300px ;text-align: center;\">Payment Date</td><td style=\"width:300px ;text-align: center;\">Amount</td></tr>
             <tr><td style=\"width:300px ;text-align: center;\">$journal_num</td><td style=\"width:300px ;text-align: center;\">$payment_date</td><td style=\"width:300px ;text-align: center;\">$fee</td></tr>
         </table>  
                    <br>

         <table border=\"1px\" >
         <tr><td colspan=\"10\"><center> <b>33. Examination Centers  </></center></td></tr>
         <tr><td style=\"width: 110px; padding-left:5px;\" ><b>Preference 1</b></td><td style=\"width: 110px;padding-left:5px\"><b>Preference 2</td><td style=\"width: 110px;padding-left:5px\"><b>Preference 3</td><td style=\"width: 110px; padding-left:5px\"><b>Preference 4</td><td style=\"width: 110px;padding-left:5px\"><b>Preference 5</td><td style=\"width: 110px;padding-left:5px\"><b>Preference 6</td><td style=\"width: 110px; padding-left:5px\"><b>Preference 7</td><td style=\"width: 110px;padding-left:5px\"><b>Preference 8</td><td style=\"width: 110px;padding-left:5px\"><b>Preference 9</td><td style=\"width: 110px;padding-left:5px;\"><b>Preference 10</td></tr>

         <tr><td style=\"max-width: 110px;text-align: center;font-size:15px; word-wrap: break-word;\">$pref_1</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_2</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_3</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_4</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_5</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_6</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_7</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_8</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_9</td><td style=\"max-width: 110px;text-align: center;font-size:15px;word-wrap: break-word;\">$pref_10</td></tr>
     </table> 

     <br>

     <table >
     <tr><td ><center><u> Declaration </u></center></td></tr>
     <tr><td style=\"width:auto;padding: 10px;\"><h5> I here by declare that all the entries/statements made in this application are true, complete and correct to the best of my knowledge and belief. In the event of any information being found false or incorrect or ineligibility being detected before or after the examination, the Commission can take action against me as per rule incase it is detected that I have misled Telangana State Public Service Commission on any issue then I will be solely responsible for all penal consequences thereof.</h5></td></tr>
     <tr><td align=\"right\" style=\"padding-right: 20px;\">Sd/-</td></tr>
     <tr><td align=\"right\" style=\"padding-right: 20px;\">$cand_name($date)</td></tr>
 </table>
 <center><h6>Copyright ©2022. Telangana State Public Service Commission. All rights reserved.
 </h6></center>   
            
 <input type=\"button\" name=\"back\" id=\"myButton\" value=\"Back\">
 <script>
 document. getElementById(\"myButton\"). onclick = function () { location. href = \"./Application.html\"; };
 </script>



                    
                                       
                     <button onClick=\"window.print()\">Confirm & Print</button>
                     </center>



               


         

   

    </div>";
    

?>
    

  


<!--


        
            
            <table >
                        <tr><td ><center> Declaration </center></td></tr>
                        <tr><td style=\"width:auto;padding: 10px;\"><h5> I here by declare that all the entries/statements made in this application are true, complete and correct to the best of my knowledge and belief. In the event of any information being found false or incorrect or ineligibility being detected before or after the examination, the Commission can take action against me as per rule incase it is detected that I have misled Telangana State Public Service Commission on any issue then I will be solely responsible for all penal consequences thereof.</h5></td></tr>
                        <tr><td align=\"right" style=\"padding-right: 20px;\">Sd/-</td></tr>
                        <tr><td align=\"right" style=\"padding-right: 20px;\">---()</td></tr>
                    </table>
                    <center><h6>Copyright ©2022. Telangana State Public Service Commission. All rights reserved.
                    </h6></center>        
                    
                    
                    

                                       </table>
                    <table border=\"1px\" style=\"width:100px;\" class=\"edu_details\">
                   <tr><td colspan=\"9\"><center><b>31. Education Details  </b></center></td></tr>
                   <tr><td style=\"max-width:123px; text-align: center;\">6th/Residence 1st yr</td><td style=\"max-width:123px ;text-align: center;\">7th/Residence 2nd yr</td><td style=\"max-width:123px ;text-align: center;\">8th/Residence 3rd yr</td><td style=\"max-width:123px ;text-align: center;\">9th/Residence 4th yr</td><td style=\"max-width:123px ;text-align: center;\">SSC</td><td style=\"max-width:123px ;text-align: center;\">Intermediate</td><td style=\"max-width:123px ;text-align: center;\">Degree</td></tr>
                   <tr><td style=\"max-width:123px ;text-align: center;\">$cls6_loc</td><td style=\"max-width:123px ;text-align: center;\">$cls7_loc</td><td style=\"max-width:123px ;text-align: center;\">$cls8_loc</td><td style=\"max-width:123px ;text-align: center;\">$cls9_loc</td><td style=\"max-width:123px ;text-align: center;\">$ssc_loc</td><td style=\"max-width:123px ;text-align: center;\">$inter_loc</td><td style=\"max-width:123px ;text-align: center;\">$degree_loc</td></tr>
               </table>
                   
            
                    <table border=\"1px\">
             <tr><td colspan=\"9\"><center><b>32. Payment Details </b> </center></td></tr>
             <tr><td style=\"width:300px; text-align: center;\">Journal Number</td><td style=\"width:300px ;text-align: center;\">Payment Date</td><td style=\"width:300px ;text-align: center;\">Amount</td></tr>
             <tr><td style=\"width:300px ;text-align: center;\">$journal_num</td><td style=\"width:300px ;text-align: center;\">$payment_date</td><td style=\"width:300px ;text-align: center;\">$fee</td></tr>
         </table>  
        

         <table border=\"1px\" >
            <tr><td colspan=\"10\"><center> <b>33. Examination Centers  </></center></td></tr>
            <tr><td style=\"width: 110px; text-align: center; padding-left:5px;\" ><b>Preference 1</b></td><td style=\"width: 110px;text-align: center;padding-left:5px\"><b>Preference 2</td><td style=\"width: 110px;text-align: center;padding-left:5px\"><b>Preference 3</td><td style=\"width: 110px; text-align: center;padding-left:5px\"><b>Preference 4</td><td style=\"width: 110px;text-align: center;padding-left:5px\"><b>Preference 5</td><td style=\"width: 110px;text-align: center;padding-left:5px\"><b>Preference 6</td><td style=\"width: 110px; text-align: center;padding-left:5px\"><b>Preference 7</td><td style=\"width: 110px;text-align: center;padding-left:5px\"><b>Preference 8</td><td style=\"width: 110px;text-align: center;padding-left:5px\"><b>Preference 9</td><td style=\"text-align: center;padding-left:5px\"><b>Preference 10</td></tr>

            <tr><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_1</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_2</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_3</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_4</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_5</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_6</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_7</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_8</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_9</td><td style=\"max-width: 110px;text-align: center;font-size:15px;\">$pref_10</td></tr>
        </table> 


            
</table>
      

                    <table class=\"tab_decl\">
                        <tr><td ><center><u> Declaration</u> </center></td></tr>
                        <tr><td style=\"width:auto;padding: 10px;\"><h5 style=\"font-weight:normal\"> I here by declare that all the entries/statements made in this application are true, complete and correct to the best of my knowledge and belief. In the event of any information being found false or incorrect or ineligibility being detected before or after the examination, the Commission can take action against me as per rule incase it is detected that I have misled Telangana State Public Service Commission on any issue then I will be solely responsible for all penal consequences thereof.</h5></td></tr>
                        <tr><td align=\"right\" style=\"padding-right: 20px;\">Sd/-</td></tr>
                        <tr><td align=\"right\" style=\"padding-right: 20px;\">$cand_name.($date)</td></tr>
                    </table>
                    <center><h6 style=\"font-weight:normal\">Copyright ©2022. Telangana State Public Service Commission. All rights reserved.
                    </h6></center>

                    <button onclick=\"history.back()\">Edit</button> 
                    
                     <button onClick=\"window.print()\">Confirm & Print</button>




-->
        
</body>
</html>