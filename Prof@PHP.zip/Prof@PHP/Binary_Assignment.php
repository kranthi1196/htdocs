<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Binary-Assignment Operators</title>
</head>
<body>
    <?php
    echo 'Assignment Operator:'; 
    echo $var=10; echo '<br>';
    echo 'Assignment Operator with addition: ';echo $var+=5;
    echo '<br>';
    echo 'Assignment Operator & Decrement Operator: ';echo $var-=5;
    echo '<br>';
    echo 'Assignment Operator & Multiplication Operator: ';echo $var*=5;
    echo '<br>';
    echo 'Assignment Operator & Division Operator: ';echo $var/=5;
    echo '<br>';
    echo 'Assignment Operator & Modulus Operator: ';echo $var%=5;
    echo '<br>';
?>
</body>
</html>