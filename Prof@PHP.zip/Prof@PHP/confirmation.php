<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./CSS/app.css">
    <title>::Confirmation Page::</title>
</head>
<body>

    <?php
    $uid=$_POST['uid'];
    $tspscid=$_POST['tspscid'];
    $refid=$_POST['refid'];
    $cand_name=$_POST['cand_name'];/*
    $fath_hus_name=$_POST['fath_hus_name'];
    $mother_name=$_POST['mother_name'];
    $dob=$_POST['dob'];
    $gender=$_POST['gender'];
    $address=$_POST['address'];
    $district=$_POST['district'];
    $mandal=$_POST['mandal'];

    $village=$_POST['village'];
    $pincode=$_POST['pincode'];
    $mobile=$_POST['mobile'];
    $email=$_POST['email'];
    $community=$_POST['community'];
    $identication_marks=$_POST['identication_marks'];
    $ex_service=$_POST['ex_service'];
    $employment=$_POST['employment'];
    $temp_emp=$_POST['temp_emp'];
    $ncc_instructor=$_POST['ncc_instructor'];
    $ph_status=$_POST['ph_status'];

    $eligibility_1_4_6_7_9=$_POST['eligibility_1_4_6_7_9'];
    $eligibility_2=$_POST['eligibility_2']; 
    $eligibility_3=$_POST['eligibility_3'];
    $eligibility_5=$_POST['eligibility_5'];
    $hindu=$_POST['hindu'];
    $photo=$_POST['photo'];
    $sign=$_POST['sign'];
    $eligibility_10=$_POST['eligibility_10'];
    $eligibility_11=$_POST['eligibility_11'];
    $eligibility_12=$_POST['eligibility_12'];
    $eligibility_13=$_POST['eligibility_13'];
    $applied_post1=$_POST['applied_post1'];

    $applied_post2=$_POST['applied_post2'];
    $applied_post3=$_POST['applied_post3'];
    $applied_post4=$_POST['applied_post4'];
    $applied_post5=$_POST['applied_post5'];
    $applied_post6=$_POST['applied_post6'];
    $applied_post7=$_POST['applied_post7'];
    $applied_post8=$_POST['applied_post8'];
    $applied_post9=$_POST['applied_post9'];
    $applied_post10=$_POST['applied_post10'];
    $applied_post11=$_POST['applied_post11'];
    $applied_post12=$_POST['applied_post12'];

    $applied_post13=$_POST['applied_post13'];
    $qualification=$_POST['qualification'];
    $university=$_POST['university'];
    $doa=$_POST['doa'];
    $deg_htnum=$_POST['deg_htnum'];
    $typeofstudy=$_POST['typeofstudy'];
    $zone=$_POST['zone'];
    $degree_loc=$_POST['degree_loc'];
    $degree_mandal_loc=$_POST['degree_mandal_loc'];
    $degree_village_loc=$_POST['degree_village_loc'];
    $inter_loc=$_POST['inter_loc'];

    $inter_mandal_loc=$_POST['inter_mandal_loc'];
    $inter_village_loc=$_POST['inter_village_loc'];
    $ssc_loc=$_POST['ssc_loc'];
    $ssc_mandal_loc=$_POST['ssc_mandal_loc'];
    $ssc_village_loc=$_POST['ssc_village_loc'];
    $cls9_loc=$_POST['cls9_loc'];
    $cls9_mandal_loc=$_POST['cls9_mandal_loc'];
    $cls9_village_loc=$_POST['cls9_village_loc'];
    $cls8_loc=$_POST['cls8_loc'];
    
    $cls8_mandal_loc=$_POST['cls8_mandal_loc']; 

    $cls8_village_loc=$_POST['cls8_village_loc'];
    $cls7_loc=$_POST['cls7_loc'];
    $cls7_mandal_loc=$_POST['cls7_mandal_loc'];
    $cls7_village_loc=$_POST['cls7_village_loc'];
    $cls6_loc=$_POST['cls6_loc'];
    $cls6_mandal_loc=$_POST['cls6_mandal_loc'];
    $cls6_village_loc=$_POST['cls6_village_loc'];
    $journal_num=$_POST['journal_num'];
    $payment_date=$_POST['payment_date'];
    $fee=$_POST['fee'];
    $pref_1=$_POST['pref_1'];

    $pref_2=$_POST['pref_2'];
    $pref_3=$_POST['pref_3'];
    $pref_4=$_POST['pref_4'];
    $pref_5=$_POST['pref_5'];
    $pref_6=$_POST['pref_6'];
    $pref_7=$_POST['pref_7'];
    $pref_8=$_POST['pref_8'];
    $pref_9=$_POST['pref_9'];
    $pref_10=$_POST['pref_10'];
    /*$=$_POST[''];
    $=$_POST[''];*/
    
    echo '<center>'.'<img class=\"tspsc_logo\" id="" src=\"./Images/TSPSC_Logo.png\" width=\"100px\" height=\"100px\" alt=\"TSPSC Logo\">'.'</center>';
    

    ?>
    


                    
        
</body>
</html>