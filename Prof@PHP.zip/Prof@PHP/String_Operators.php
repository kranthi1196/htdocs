<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>String Operators</title>
</head>
<body>
    <?php
echo '******************************'.'<br>';
echo 'Program on String Operators'.'<br>';
echo '******************************'.'<br>';

$var='Kranthi';
$var1='Kumar';
echo 'String Concatination:'.$var." ".$var1.'<br>';
echo 'String Concatination and Adding it to First String:'.$var.=$var1.'<br>';
echo $var;

?>
</body>
</html>


