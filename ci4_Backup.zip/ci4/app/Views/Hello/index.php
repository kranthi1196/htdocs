
<?php 
include 'headerview.php'; 
include 'myview.php';
include 'footerview.php';
?>
