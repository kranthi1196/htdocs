<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ci4</title>
</head>
<body>
    <h2>welcome to Ci4, This is MyView from Views/Hello Folder</h2>
    <table border='1px' cellspacing='0px'>
        <tr>
            <td><b>S.No. </b></td> <td><b>First Name</b></td><td><b>Last Name</b></td><td><b>Address</b></td>
        </tr>
        <tr>
        <td>1. </td> <td>Kranthi</td> <td>Kumar</td> <td>Suryapet</td>
        </tr>
    </table>
</body>
</html>